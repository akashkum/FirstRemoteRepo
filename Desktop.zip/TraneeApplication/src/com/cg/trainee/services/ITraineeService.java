package com.cg.trainee.services;

import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;

public interface ITraineeService {
	void addTrainee(Trainee trainee) throws TraineeException;
}
