package com.cg.trainee.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;
import com.cg.trainee.services.ITraineeService;

@Controller
public class TraineeController {
	
	@Resource
	private ITraineeService service;
	
	
	@RequestMapping("/login.do")
	public ModelAndView getHomePage(HttpServletRequest request){
		ModelAndView mAndV = new ModelAndView();
		String userName=request.getParameter("userName").trim();
		String password=request.getParameter("password").trim();
		if("system".equals(userName) &&"sys".equals(password))
		{
			mAndV.setViewName("HomePage");
		}
		else{
			mAndV.addObject("msg","Incorrect credentials");
			mAndV.setViewName("Login");
		}
		return mAndV;
	}
	
	@RequestMapping("/getEntryPage.do")
	public ModelAndView getEntryPage(){
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("TraineeDetailsEntry");
		Trainee trainee = new Trainee(); //command object
		mAndV.addObject("trainee", trainee);
		return mAndV;
	}
	
	@RequestMapping(value="/addTrainee.do", method=RequestMethod.POST)
	public ModelAndView addTrainee(@ModelAttribute("trainee") Trainee trainee) throws TraineeException{
		System.out.println(trainee);
		service.addTrainee(trainee);
		System.out.println(trainee);
		ModelAndView mAndV = new ModelAndView();
		mAndV.addObject("trainee", trainee);
		mAndV.addObject("pageHead", "Trainee Added Successfully"); 
		mAndV.setViewName("SuccessfullyTraineeAdded");
		return mAndV;
	}
}
