package com.cg.trainee.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;
@Repository
public class TraineeDaoImpl implements ITraineeDao {
	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public void addTrainee(Trainee trainee) throws TraineeException {
		manager.persist(trainee);
	}
}
