package com.cg.trainee.entities;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Table(name="Trainee")
@Entity
public class Trainee implements Serializable{

	private static final long serialVersionUID = 1L;
	private String traineeId;
	private String name;
	private String loaction;
//private LocalDate date;
	private String domain;
	
	public Trainee() {
		super();
	}


	public Trainee(String traineeId, String name, String loaction,
			/*LocalDate date, */String domain) {
		super();
		this.traineeId = traineeId;
		this.name = name;
		this.loaction = loaction;
		//this.date = date;
		this.domain = domain;
	}
	
	
	@Id
	public String getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(String traineeId) {
		this.traineeId = traineeId;
	}
	@Column(name="Trainee_name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getLoaction() {
		return loaction;
	}
	public void setLoaction(String loaction) {
		this.loaction = loaction;
	}
	/*@Temporal(TemporalType.DATE)
	@Column(name="joining_date")
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}*/
	
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}


	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", name=" + name
				+ ", loaction=" + loaction + ", domain="
				+ domain + "]";
	}
	
	
}
