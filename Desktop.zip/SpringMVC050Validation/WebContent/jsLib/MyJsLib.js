$(document).ready(
		function(){
			$('h1').css({"color":"green","font-size":"30px","text-align":"center"});
			$("#mainMenu a").css({"color":"#376522","font-size":"30px"});
			$("#mainMenu a").hover(
					function() {
						$(this).css({"color":"red","font-size":"20px"})
					},
					function() {
						$(this).css({"color":"blue","font-size":"14px"})
					}
			);
			$("table tr:odd").css({"background-color":"lightblue"});
			$("table tr:even").css({"background-color":"lightgreen"});
		}

)