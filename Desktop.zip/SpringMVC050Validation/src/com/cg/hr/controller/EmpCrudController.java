package com.cg.hr.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hr.entities.Employee;
import com.cg.hr.exception.EmpException;
import com.cg.hr.services.EmpService;

@Controller
public class EmpCrudController {
	@Resource
	private EmpService service;
	@RequestMapping("/getHomePage.do")
	public ModelAndView getHomePage(){
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("HomePage");
		return mAndV;
	}
	@RequestMapping("/getEmpList.do")
	public ModelAndView getEmpList() throws EmpException{ 
		List<Employee> empList = service.getEmpList();
		ModelAndView mAndV = new ModelAndView();
		mAndV.addObject("empList", empList);
		mAndV.addObject("pageHead", "Employee List");
		mAndV.setViewName("EmpList");
		return mAndV;
	}
	
	@RequestMapping("/getEmpDetails.do")
	public ModelAndView getEmpDetails(@RequestParam("empNo") int empNo) throws EmpException{
		Employee emp = service.getEmpOnId(empNo);
		ModelAndView mAndV = new ModelAndView();
		mAndV.addObject("emp", emp);
		mAndV.addObject("pageHead", "Employee Details"); 
		mAndV.setViewName("EmpDetails");
		return mAndV;
		
	}
	@RequestMapping("/getEntryPage.do")
	public ModelAndView getEntryPage(){
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("EntryPage");
		Employee emp =  new Employee(); //command object
		mAndV.addObject("employee", emp);
		return mAndV;
	}
	@RequestMapping(value= "/submitEmpDetails.do", method= RequestMethod.POST)
	public ModelAndView submitEmpDetails(@ModelAttribute("employee") @Valid Employee emp , BindingResult result) throws EmpException{
		
		ModelAndView mAndV = new ModelAndView();
		System.out.println(emp);
		if(result.hasErrors()){
			mAndV.setViewName("EntryPage");
		}else{
			service.insertNewEmp(emp);
			System.out.println(emp);
			mAndV.addObject("emp", emp);
			mAndV.addObject("pageHead", "Employee Added Successfully"); 
			mAndV.setViewName("SuccEmpJoining");
		}
		return mAndV;	
	}
	
	@RequestMapping(value= "/submitEmpName.do", method= RequestMethod.GET)
	public String submitEmpName(
			@RequestParam("empNo") int empNo,
			@RequestParam("newName") String newName,
			Model mAndV
			) throws EmpException{
		
		System.out.println(empNo + " " + newName);
		service.updateEmpName(empNo, newName);
		
		//System.out.println(emp);
		Employee emp = service.getEmpOnId(empNo);
		mAndV.addAttribute("emp", emp);
		mAndV.addAttribute("pageHead", "Employee updated Successfully"); 
		//mAndV.setViewName("SuccEmpUpdate");
		return "SuccEmpUpdate";
		
	}
	
	@RequestMapping("/getUpdateNamePage.do")
	public ModelAndView getUpdateNamePage() throws EmpException{
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("UpdateNamePage");
		//Employee emp =  new Employee(); //command object
		List<Integer> idList = service.getEmpNoList();
		mAndV.addObject("idList", idList);
		mAndV.addObject("pageHead", "Update name");
		return mAndV;
	}
}
