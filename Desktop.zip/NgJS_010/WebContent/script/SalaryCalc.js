//A factory method .module() creates module object
var taxModule = angular.module("taxModule", []);

//A module has a factory method .controller to create controller
taxModule.controller("taxController", function($scope){
	$scope.salary = {
			'ctc' 		: 0,
	}; //object in javascript
	
	$scope.calcBasic = function(){
		return $scope.salary.ctc * 0.5;
	};
	
	$scope.calcHRA = function(){
		return $scope.calcBasic() * 0.4;
	};
	
	$scope.calcTA = function(){
		return 1200*12;
	};

	$scope.calcGrossSalary = function() {
		return $scope.calcBasic() + $scope.calcHRA() + $scope.calcTA();
	};
	
	$scope.calcTDS = function() {
		return $scope.calcGrossSalary()*0.1;
	};
	$scope.calcDeduction = function() {
		return 2500+$scope.calcTDS();
	};
	$scope.netSalary = function() {
		return $scope.calcGrossSalary() - $scope.calcTDS()-2500;
	};
}
);