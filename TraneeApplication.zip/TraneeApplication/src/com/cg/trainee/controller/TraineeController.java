package com.cg.trainee.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;
import com.cg.trainee.services.ITraineeService;

@Controller
public class TraineeController {
	
	@Resource
	private ITraineeService service;
	
	
	@RequestMapping("/login.do")
	public ModelAndView getHomePage(HttpServletRequest request){
		ModelAndView mAndV = new ModelAndView();
		String userName=request.getParameter("userName").trim();
		String password=request.getParameter("password").trim();
		if("system".equals(userName) &&"sys".equals(password))
		{
			mAndV.setViewName("HomePage");
		}
		else{
			mAndV.addObject("msg","Incorrect credentials");
			mAndV.setViewName("Login");
		}
		return mAndV;
	}
	
	@RequestMapping("/getEntryPage.do")
	public ModelAndView getEntryPage(){
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("TraineeDetailsEntry");
		Trainee trainee = new Trainee(); //command object
		mAndV.addObject("trainee", trainee);
		return mAndV;
	}
	
	@RequestMapping(value="/addTrainee.do", method=RequestMethod.POST)
	public ModelAndView addTrainee(@ModelAttribute("trainee") Trainee trainee) throws TraineeException{
		System.out.println(trainee);
		service.addTrainee(trainee);
		System.out.println(trainee);
		ModelAndView mAndV = new ModelAndView();
		mAndV.addObject("trainee", trainee);
		mAndV.addObject("pageHead", "Trainee Added Successfully"); 
		mAndV.setViewName("SuccessfullyTraineeAdded");
		return mAndV;
	}
	
	@RequestMapping(value="/getDeleteTrainee.do",method=RequestMethod.GET)
	public ModelAndView deleteTrainee(){
		System.out.println("Are in trainee Delete");
		ModelAndView mAndV = new ModelAndView();
		mAndV.addObject("traineeId", null);
		mAndV.setViewName("DeleteTrainee");
		return mAndV;
	}
	@RequestMapping(value="/getTrainebyId.do",method=RequestMethod.POST)
	public ModelAndView getTrainebyId(HttpServletRequest request) throws TraineeException {
		System.out.println("Are in trainee Delete2");
		ModelAndView mAndV = new ModelAndView();
		String traineeId = request.getParameter("traineeId").trim();
		mAndV.addObject("traineeId", traineeId);
		Trainee trainee=service.getTrainebyId(traineeId);
		if(trainee!=null){
			mAndV.addObject("trainee", trainee);
		}else{
			mAndV.addObject("trainee", null);
			mAndV.addObject("msg", "Trainne Not Available");
		}
		mAndV.setViewName("DeleteTrainee");
		return mAndV;
	}
	@RequestMapping(value="/delete.do",method=RequestMethod.POST)
	public ModelAndView deleteTraine(HttpServletRequest request) throws TraineeException {
		System.out.println("Are in trainee Delete3");
		ModelAndView mAndV = new ModelAndView();
		Trainee trainee = request.getParameter("trainee");
		service.deleteTrainee(trainee);
		mAndV.setViewName("DeleteTrainee");
		return mAndV;
	}
}
