package com.cg.trainee.controller;

import java.util.ArrayList;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;




import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;





import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;
import com.cg.trainee.services.ITraineeService;

@Controller
public class TraineeController {
	
	@Resource
	private ITraineeService service;
	
	
	
	@RequestMapping("/login.do")
	public ModelAndView getHomePage(HttpServletRequest request){
		ModelAndView mAndV = new ModelAndView();
		String userName=request.getParameter("userName").trim();
		String password=request.getParameter("password").trim();
		if("system".equals(userName) &&"sys".equals(password))
		{
			mAndV.setViewName("HomePage");
		}
		else{
			mAndV.addObject("msg","Incorrect credentials");
			mAndV.setViewName("Login");
		}
		return mAndV;
	}
	
	@RequestMapping("/HomePage.do")
	public ModelAndView goHomePage(){
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("HomePage");
		return mAndV;
	}
	
	@RequestMapping("/getEntryPage.do")
	public ModelAndView getEntryPage(){
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("TraineeDetailsEntry");
		Trainee trainee = new Trainee(); //command object
		mAndV.addObject("trainee", trainee);
		return mAndV;
	}
	
	@RequestMapping(value="/addTrainee.do", method=RequestMethod.POST)
	public ModelAndView addTrainee(@ModelAttribute("trainee") Trainee trainee) throws TraineeException{
		System.out.println(trainee);
		service.addTrainee(trainee);
		System.out.println(trainee);
		ModelAndView mAndV = new ModelAndView();
		mAndV.addObject("trainee", trainee);
		mAndV.addObject("pageHead", "Trainee Added Successfully"); 
		mAndV.setViewName("SuccessfullyTraineeAdded");
		return mAndV;
	}
	
	@RequestMapping(value="/getDeleteTrainee.do",method=RequestMethod.GET)
	public ModelAndView deleteTrainee(){
		System.out.println("Are in trainee Delete");
		ModelAndView mAndV = new ModelAndView();
		mAndV.addObject("traineeId", null);
		mAndV.setViewName("DeleteTrainee");
		return mAndV;
	}
	@RequestMapping(value="/getTrainebyId.do",method=RequestMethod.POST)
	public ModelAndView getTrainebyId(@RequestParam("traineeId") String traineeId) throws TraineeException {
		System.out.println("Are in trainee Delete2");
		ModelAndView mAndV = new ModelAndView();
		mAndV.addObject("traineeId", traineeId);
		Trainee trainee=service.getTrainebyId(traineeId); //command object
		if(trainee!=null){
			mAndV.addObject("trainee", trainee);
			mAndV.addObject("msg", null);
		}else{
			mAndV.addObject("trainee", null);
			mAndV.addObject("msg", "Trainne Not Available");
		}
		mAndV.setViewName("DeleteTrainee");
		return mAndV;
	}
	@RequestMapping(value="/delete.do",method=RequestMethod.POST)
	public ModelAndView deleteTraine(@RequestParam("traineeId") String traineeId) throws TraineeException {
		System.out.println("Are in trainee Delete3");
		ModelAndView mAndV = new ModelAndView();
		mAndV.addObject("traineeId", traineeId);
		Trainee trainee=service.getTrainebyId(traineeId);
		System.out.println(trainee);
		service.deleteTrainee(traineeId);
		mAndV.addObject("msg", "Object Deleted");
		mAndV.setViewName("DeleteTrainee");
		return mAndV;
	}
	
	@RequestMapping(value="/getmodifyTrainee.do",method=RequestMethod.GET)
	public ModelAndView getmodifyTrainee(){
		System.out.println("Are in trainee Delete");
		ModelAndView mAndV = new ModelAndView();
		mAndV.addObject("traineeId", null);
		mAndV.setViewName("ModifyPage");
		return mAndV;
	}
	
	@RequestMapping(value="/showTraineeModify.do",method=RequestMethod.POST)
	public ModelAndView showTraineeModify(@RequestParam("traineeId") String traineeId) throws TraineeException {
		System.out.println("Are in trainee Modify2");
		ModelAndView mAndV = new ModelAndView();
		mAndV.addObject("traineeId", traineeId);
		Trainee trainee=service.getTrainebyId(traineeId); //command object
		if(trainee!=null){
			mAndV.addObject("trainee", trainee);
			mAndV.addObject("msg", null);
		}else{
			mAndV.addObject("trainee", null);
			mAndV.addObject("msg", "Trainee Not Available");
		}
		mAndV.setViewName("ModifyPage");
		return mAndV;
	}
	
	@RequestMapping(value="/updateTrainee.do",method=RequestMethod.POST)
	public ModelAndView updateTrainee(@ModelAttribute("trainee") Trainee trainee) {
		System.out.println("Are in trainee updtae3");
		ModelAndView mAndV = new ModelAndView();
		System.out.println(trainee);
		try {
			service.updatetrainee(trainee);
			mAndV.addObject("msg", "Object updated");
		} catch (TraineeException e) {
			System.out.println("adhjafgdfhasjk");
			mAndV.addObject("msg", "Object problem in updating"+e.getMessage());
		}
		mAndV.setViewName("ModifyPage");
		return mAndV;
	}
	
	@RequestMapping("/retrieveTraineesbydomain.do")
	public ModelAndView retrieveTraineesbydomain(){
		System.out.println("Are in trainee get domain");
		ModelAndView mAndV = new ModelAndView();
		mAndV.addObject("domain", null);
		mAndV.setViewName("Domain");
		return mAndV;
	}
	@RequestMapping("/byDomain.do")
	public ModelAndView byDomain(@RequestParam("domain") String domain) throws TraineeException{
		System.out.println("Are in trainee Domain get");
		ModelAndView mAndV = new ModelAndView();
		ArrayList<String> list=service.getTraineeByDomain(domain);
		System.out.println(list);
		mAndV.setViewName("Domain");
		return mAndV;
	}
}
