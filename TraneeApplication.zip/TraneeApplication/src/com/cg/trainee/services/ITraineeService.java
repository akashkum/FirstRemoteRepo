package com.cg.trainee.services;

import java.util.ArrayList;

import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;

public interface ITraineeService {
	void addTrainee(Trainee trainee) throws TraineeException;
	
	Trainee getTrainebyId(String traineeId) throws TraineeException;

	void deleteTrainee(String traineeId) throws TraineeException;

	void updatetrainee(Trainee trainee) throws TraineeException;
	
	public ArrayList<String> getTraineeByDomain(String domain)
			throws TraineeException;
}
