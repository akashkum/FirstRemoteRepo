package com.cg.trainee.services;

import java.util.ArrayList;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.trainee.dao.ITraineeDao;
import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;
@Transactional
@Service

public class TraineeServiceImpl implements ITraineeService{
	@Resource
	private ITraineeDao dao;
	
	@Override
	public void addTrainee(Trainee trainee) throws TraineeException {
		dao.addTrainee(trainee);
	}

	@Override
	public void deleteTrainee(String traineeId) throws TraineeException {
		dao.deleteTrainee(traineeId);
		
	}

	@Override
	public Trainee getTrainebyId(String traineeId) throws TraineeException {
		return dao.getTrainebyId(traineeId);
	}

	@Override
	public void updatetrainee(Trainee trainee) throws TraineeException {
		dao.updatetrainee(trainee);
		
	}

	@Override
	public ArrayList<String> getTraineeByDomain(String domain)
			throws TraineeException {
		
		return dao.getTraineeByDomain(domain);
	}

}