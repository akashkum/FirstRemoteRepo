package com.cg.trainee.services;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.trainee.dao.ITraineeDao;
import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;
@Transactional
@Service

public class TraineeServiceImpl implements ITraineeService{
	@Resource
	private ITraineeDao dao;
	
	@Override
	public void addTrainee(Trainee trainee) throws TraineeException {
		dao.addTrainee(trainee);
	}

	@Override
	public void deleteTrainee(Trainee trainee) throws TraineeException {
		dao.deleteTrainee(trainee);
		
	}

	@Override
	public Trainee getTrainebyId(String traineeId) throws TraineeException {
		return dao.getTrainebyId(traineeId);
	}

}