package com.cg.trainee.dao;

import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;

public interface ITraineeDao {
	void addTrainee(Trainee trainee) throws TraineeException;

	void deleteTrainee(Trainee trainee) throws TraineeException;

	Trainee getTrainebyId(String traineeId) throws TraineeException;
}
