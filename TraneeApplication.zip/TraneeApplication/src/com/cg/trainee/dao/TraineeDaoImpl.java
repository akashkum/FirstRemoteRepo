package com.cg.trainee.dao;

import java.util.ArrayList;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;
@Repository
public class TraineeDaoImpl implements ITraineeDao {
	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public void addTrainee(Trainee trainee) throws TraineeException {
		manager.persist(trainee);
	}

	@Override
	public void deleteTrainee(String traineeId) throws TraineeException {
		manager.remove(manager.find(Trainee.class,traineeId));
	}

	@Override
	public Trainee getTrainebyId(String traineeId) throws TraineeException {
		Trainee trainee = manager.find(Trainee.class, traineeId);
		if(trainee==null){
		return null;
		}else{
			return trainee;
		}
	}
	
	@Override
	public void updatetrainee(Trainee trainee) throws TraineeException {
		System.out.println(trainee);
		Trainee trainee2 = manager.find(Trainee.class, trainee.getTraineeId());
		System.out.println(trainee2);
		System.out.println(trainee);
		try {
			trainee2.setTraineeId(trainee.getTraineeId());
			trainee2.setName(trainee.getName());
			trainee2.setLoaction(trainee.getLoaction());
			trainee2.setDomain(trainee.getDomain());
		} catch (Exception e) {
			throw new TraineeException("could not update"+e.getMessage());
		}
	}

	@Override
	public ArrayList<String> getTraineeByDomain(String domain)
			throws TraineeException {
		ArrayList<String> domainList = new ArrayList<>();
		String qry = "Select t.domain from Trainee t Where t.domain=:domain";
		TypedQuery<String> domainQry = manager.createQuery(qry, String.class);
		domainQry.setParameter("domain", domain);
		domainList = (ArrayList<String>) domainQry.getResultList();
		System.out.println("here in domaibnajksdfhasjkfn"+domainList);
		return domainList;
	}
	
}
