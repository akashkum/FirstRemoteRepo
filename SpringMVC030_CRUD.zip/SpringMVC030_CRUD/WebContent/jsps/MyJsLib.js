$(document).ready(
		function(){
			alert('yes here');
		}

)