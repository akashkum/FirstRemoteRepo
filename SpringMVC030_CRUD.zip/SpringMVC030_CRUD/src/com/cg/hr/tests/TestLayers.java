package com.cg.hr.tests;

import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.hr.entities.Employee;
import com.cg.hr.exception.EmpException;
import com.cg.hr.services.EmpService;

public class TestLayers {

	public static void main(String[] args) {
	ConfigurableApplicationContext ctx = new ClassPathXmlApplicationContext("classpath:EmpManagement.xml");
	
	try {
		EmpService service = ctx.getBean(EmpService.class);
		List<Employee> empList = service.getEmpList();
	} catch (BeansException e) { 
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (EmpException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	}

}
